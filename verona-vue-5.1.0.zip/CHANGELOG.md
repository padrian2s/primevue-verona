# Changelog

## 5.1.0 (2024-12-03)

**Implemented New Features and Enhancements**

-   Refactored dashboard sections to components
-   Migrate sass from @import to @use

## 5.0.0 (2024-08-27)

**Implemented New Features and Enhancements**

-   Upgrade to PrimeVue v4

**Migration Guide**

-   Remove theme files: public/layout/styles/themes folder in favor of new v4 theming.
-   Replace PrimeFlex with Tailwind CSS, for more information: https://primevue.org/tailwind/
-   PrimeVue auto-import and tree-shaking implementation is enabled. For more information: https://primevue.org/autoimport/

## 4.2.0 (2024-03-11)

**Migration Guide**

-   Update theme files.

**Implemented New Features and Enhancements**

-   Upgrade to PrimeVue 3.49.1

## 4.1.0 (2023-11-10)

**Migration Guide**

-   Update theme files.
-   public/layout/preloading.scss file moved under public/layout/styles/preloading folder.
-   public/theme folder moved under public/layout/styles/theme folder.

**Implemented New Features and Enhancements**

-   Upgrade to PrimeVue 3.36.0

## 4.0.0 (2023-07-23)

**Implemented New Features and Enhancements**

-   Migrated to NextGen implementation.
-   New sample apps
-   New sample pages
-   New landing
-   New dashboards

## 3.0.0 (2023-04-12)

**Implemented New Features and Enhancements**

-   Migrated to Vite from Vue-CLI

## 2.0.0 (2023-01-26)

**Migration Guide**

-   Update theme files.

**Implemented New Features and Enhancements**

-   Upgrade to PrimeVue 3.22.4
-   Upgrade to PrimeFlex 3.3.0
-   Upgrade to PrimeIcons 6.0.1
-   New styles of PrimeVue components
