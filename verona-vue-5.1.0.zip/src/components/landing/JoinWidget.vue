<template>
    <div class="px-8 sm:px-20 py-20 bg-surface-50 dark:bg-surface-950 flex flex-wrap gap-8 items-center justify-between">
        <div class="text-4xl font-bold">Join the Prime Community</div>
        <Button label="Join Now" class="p-button-raised"></Button>
    </div>
</template>
