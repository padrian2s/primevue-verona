<script setup>
import { useRouter } from 'vue-router';

const router = useRouter();

function navigateToRegister() {
    router.push('/auth/register');
}

function navigateToDashboard() {
    router.push('/');
}

function scrollTo(id) {
    setTimeout(() => {
        const element = document.getElementById(id);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
        }
    }, 200);
}
</script>

<template>
    <div class="flex items-center justify-between px-8 sm:px-20 py-12">
        <a @click="navigateToDashboard" class="cursor-pointer">
            <span class="text-2xl font-bold text-color">VERONA</span>
        </a>
        <div class="relative">
            <Button
                rounded
                class="cursor-pointer lg:!hidden select-none w-12 h-12 !text-color"
                v-styleclass="{ selector: '@next', enterFromClass: 'hidden', enterActiveClass: 'animate-scalein', leaveToClass: 'hidden', leaveActiveClass: 'animate-fadeout', leaveToClass: 'hidden', hideOnOutsideClick: 'true' }"
            >
                <i class="pi pi-bars !text-4xl"></i>
            </Button>
            <div
                id="landing-menu"
                class="hidden lg:block absolute right-0 top-auto lg:static z-10 shadow lg:shadow-none w-60 lg:w-auto bg-surface-0 dark:bg-surface-900 lg:bg-surface-50 dark:lg:bg-surface-950 origin-top p-4 lg:p-0"
                style="border-radius: 14px"
            >
                <ul class="flex flex-col lg:flex-row m-0 p-0 list-none text-2xl lg:text-base">
                    <li>
                        <a
                            class="block p-4 cursor-pointer font-bold text-muted-color hover:text-color transition-colors duration-300"
                            @click="scrollTo('stats')"
                            v-styleclass="{ selector: '#landing-menu', leaveActiveClass: 'animate-fadeout', leaveToClass: 'hidden' }"
                            >STATS</a
                        >
                    </li>
                    <li>
                        <a
                            class="block p-4 cursor-pointer font-bold text-muted-color hover:text-color transition-colors duration-300"
                            @click="scrollTo('features')"
                            v-styleclass="{ selector: '#landing-menu', leaveActiveClass: 'animate-fadeout', leaveToClass: 'hidden' }"
                            >FEATURES</a
                        >
                    </li>
                    <li>
                        <a
                            class="block p-4 cursor-pointer font-bold text-muted-color hover:text-color transition-colors duration-300"
                            @click="scrollTo('pricing')"
                            v-styleclass="{ selector: '#landing-menu', leaveActiveClass: 'animate-fadeout', leaveToClass: 'hidden' }"
                            >PRICING</a
                        >
                    </li>
                    <li>
                        <a class="block p-4 cursor-pointer font-bold text-muted-color hover:text-color transition-colors duration-300" @click="navigateToRegister">SIGN IN</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>
