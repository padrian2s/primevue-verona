<template>
    <div class="card h-full">
        <div class="font-semibold text-xl">Latest Customers</div>
        <ul class="list-none p-0 m-0 mt-6">
            <li class="mb-6 flex items-center">
                <Avatar label="BS" size="large" shape="circle" class="text-base font-bold" :style="{ 'background-color': 'rgba(101, 214, 173, 0.1)', color: '#27AB83', border: '1px solid #65D6AD' }"></Avatar>
                <div class="ml-4">
                    <span class="block">Brooklyn Simmons</span>
                    <span class="text-muted-color block">Manager at Mitsubishi</span>
                </div>
            </li>
            <li class="mb-6 flex items-center">
                <Avatar label="LA" size="large" shape="circle" class="text-base font-bold" :style="{ 'background-color': 'rgba(250, 219, 95, 0.1)', color: '#DE911D', border: '1px solid #FADB5F' }"></Avatar>
                <div class="ml-4">
                    <span class="block">Leslie Alexander</span>
                    <span class="text-muted-color block">Customer Success at General Electric</span>
                </div>
            </li>
            <li class="mb-6 flex items-center">
                <Avatar label="JB" size="large" shape="circle" class="text-base font-bold" :style="{ 'background-color': 'rgba(94, 208, 250, 0.1)', color: '#1992D4', border: '1px solid #5ED0FA' }"></Avatar>
                <div class="ml-4">
                    <span class="block">Jerome Bell</span>
                    <span class="text-muted-color block">Mario Carrier at Nintendo</span>
                </div>
            </li>
            <li class="mb-6 flex items-center">
                <Avatar label="JJ" size="large" shape="circle" class="text-base font-bold" :style="{ 'background-color': 'rgba(43, 176, 237, 0.1)', color: '#127FBF', border: '1px solid #2BB0ED' }"></Avatar>
                <div class="ml-4">
                    <span class="block">Jim Jones</span>
                    <span class="text-muted-color block">Reliability Engineer at eBay</span>
                </div>
            </li>
            <li class="mb-6 flex items-center">
                <Avatar label="AB" size="large" shape="circle" class="text-base font-bold" :style="{ 'background-color': 'rgba(255, 155, 155, 0.1)', color: '#CF1124', border: '1px solid #FF9B9B' }"></Avatar>
                <div class="ml-4">
                    <span class="block">Annette Black</span>
                    <span class="text-muted-color block">Delivery Woman at Pizza Hut</span>
                </div>
            </li>
            <li class="mb-6 flex items-center">
                <Avatar label="AF" size="large" shape="circle" class="text-base font-bold" :style="{ 'background-color': 'rgba(250, 219, 95, 0.1)', color: '#DE911D', border: '1px solid #FADB5F' }"></Avatar>
                <div class="ml-4">
                    <span class="block">Albert Flores</span>
                    <span class="text-muted-color block">Team Leader at Insomniac Games</span>
                </div>
            </li>
        </ul>
        <Button type="button" class="w-full mt-4" label="View All" icon="pi pi-arrow-right" iconPos="right"></Button>
    </div>
</template>
