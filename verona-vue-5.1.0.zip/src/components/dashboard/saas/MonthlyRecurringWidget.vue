<script setup>
import { useLayout } from '@/layout/composables/layout';
import { ref, watch } from 'vue';

const { getPrimary, getSurface, isDarkTheme } = useLayout();

const revenueChartData = ref(null);
const revenueChartOptions = ref(null);

function initCharts() {
    const documentStyle = getComputedStyle(document.documentElement);
    const textColorSecondary = documentStyle.getPropertyValue('--text-color-secondary');
    const borderColor = documentStyle.getPropertyValue('--surface-border');

    revenueChartData.value = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                data: [11, 17, 30, 60, 88, 92],
                borderColor: 'rgba(25, 146, 212, 0.5)',
                pointBorderColor: 'transparent',
                pointBackgroundColor: 'transparent',
                fill: false,
                tension: 0.4
            },
            {
                data: [11, 19, 39, 59, 69, 71],
                borderColor: 'rgba(25, 146, 212, 0.5)',
                pointBorderColor: 'transparent',
                pointBackgroundColor: 'transparent',
                fill: false,
                tension: 0.4
            },
            {
                data: [11, 17, 21, 30, 47, 83],
                backgroundColor: 'rgba(25, 146, 212, 0.2)',
                borderColor: 'rgba(25, 146, 212, 0.5)',
                pointBorderColor: 'transparent',
                pointBackgroundColor: 'transparent',
                fill: true,
                tension: 0.4
            }
        ]
    };

    revenueChartOptions.value = {
        plugins: {
            legend: {
                display: false
            }
        },
        maintainAspectRatio: false,
        scales: {
            y: {
                grid: {
                    color: borderColor
                },
                max: 100,
                min: 0,
                ticks: {
                    color: textColorSecondary
                }
            },
            x: {
                grid: {
                    color: borderColor
                },
                ticks: {
                    color: textColorSecondary,
                    beginAtZero: true
                }
            }
        }
    };
}

watch(
    [getPrimary, getSurface, isDarkTheme],
    () => {
        initCharts();
    },
    { immediate: true }
);
</script>

<template>
    <div class="card">
        <div class="font-semibold text-xl mb-4">Monthly Recurring Revenue Growth</div>
        <Chart type="line" :height="370" :data="revenueChartData" :options="revenueChartOptions" id="nasdaq-chart"></Chart>
    </div>
</template>
