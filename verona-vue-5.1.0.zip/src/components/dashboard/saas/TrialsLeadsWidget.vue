<template>
    <div class="card h-full">
        <div class="font-semibold text-xl">Trials Leads By Role</div>
        <div class="flex items-center justify-between pb-2 mb-1 pt-4 border-b border-surface">
            <span class="font-bold">Role</span>
            <span class="font-bold">Leads</span>
        </div>
        <ul class="list-none p-0 m-0">
            <li class="flex flex-wrap items-center justify-between py-1">
                <span>Finance</span>
                <AvatarGroup class="w-32 justify-evenly">
                    <Avatar image="/demo/images/avatar/amyelsner.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/asiyajavayant.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/onyamalimba.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/ionibowcher.png" shape="circle"></Avatar>
                </AvatarGroup>
            </li>
            <li class="flex flex-wrap items-center justify-between py-1">
                <span>Management</span>
                <AvatarGroup class="w-24 justify-evenly">
                    <Avatar image="/demo/images/avatar/annafali.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/bernardodominic.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/elwinsharvill.png" shape="circle"></Avatar>
                </AvatarGroup>
            </li>
            <li class="flex flex-wrap items-center justify-between py-1">
                <span>Human Resources</span>
                <AvatarGroup class="w-16 justify-evenly">
                    <Avatar image="/demo/images/avatar/ivanmagalhaes.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/onyamalimba.png" shape="circle"></Avatar>
                </AvatarGroup>
            </li>
            <li class="flex flex-wrap items-center justify-between py-2">
                <span>Development</span>
                <AvatarGroup class="w-32 justify-evenly">
                    <Avatar image="/demo/images/avatar/amyelsner.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/asiyajavayant.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/onyamalimba.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/ionibowcher.png" shape="circle"></Avatar>
                </AvatarGroup>
            </li>
            <li class="flex flex-wrap items-center justify-between py-2">
                <span>Design</span>
                <AvatarGroup class="w-16 justify-evenly">
                    <Avatar image="/demo/images/avatar/amyelsner.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/asiyajavayant.png" shape="circle"></Avatar>
                </AvatarGroup>
            </li>
            <li class="flex flex-wrap items-center justify-between py-2">
                <span>R&D</span>
                <AvatarGroup class="w-24 justify-evenly">
                    <Avatar image="/demo/images/avatar/amyelsner.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/asiyajavayant.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/onyamalimba.png" shape="circle"></Avatar>
                </AvatarGroup>
            </li>
            <li class="flex flex-wrap items-center justify-between py-2">
                <span>Reliability</span>
                <AvatarGroup class="w-16 justify-evenly">
                    <Avatar image="/demo/images/avatar/amyelsner.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/asiyajavayant.png" shape="circle"></Avatar>
                </AvatarGroup>
            </li>
            <li class="flex flex-wrap items-center justify-between py-2">
                <span>Social Media</span>
                <AvatarGroup class="w-32 justify-evenly">
                    <Avatar image="/demo/images/avatar/amyelsner.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/asiyajavayant.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/onyamalimba.png" shape="circle"></Avatar>
                    <Avatar image="/demo/images/avatar/ionibowcher.png" shape="circle"></Avatar>
                </AvatarGroup>
            </li>
        </ul>
    </div>
</template>
