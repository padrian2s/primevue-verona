<script setup>
import { useLayout } from '@/layout/composables/layout';
import { ref, watch } from 'vue';

const { getPrimary, getSurface, isDarkTheme } = useLayout();

const overviewWeeks = ref([
    { name: 'Last Week', code: '0' },
    { name: 'This Week', code: '1' }
]);

const selectedOverviewWeek = ref(overviewWeeks.value.find((week) => week.name === 'Last Week'));

const overviewChartData = ref(null);

const overviewChartOptions = ref(null);

const changeOverviewWeek = () => {
    const dataSet1 = [
        [2, 1, 0.5, 0.6, 0.5, 1.3, 1],
        [4.88, 3, 6.2, 4.5, 2.1, 5.1, 4.1]
    ];
    const dataSet2 = [
        [3, 2.4, 1.5, 0.6, 4.5, 3.3, 2],
        [3.2, 4.1, 2.2, 5.5, 4.1, 3.6, 3.5]
    ];

    if (selectedOverviewWeek.value.code === '1') {
        overviewChartData.value.datasets[0].data = dataSet2[parseInt('0')];
        overviewChartData.value.datasets[1].data = dataSet2[parseInt('1')];
    } else {
        overviewChartData.value.datasets[0].data = dataSet1[parseInt('0')];
        overviewChartData.value.datasets[1].data = dataSet1[parseInt('1')];
    }

    // Forcing the reactivity
    overviewChartData.value = { ...overviewChartData.value };
};

function initCharts() {
    const documentStyle = getComputedStyle(document.documentElement);
    const textColorSecondary = documentStyle.getPropertyValue('--text-color-secondary');
    const primaryColor = documentStyle.getPropertyValue('--primary-color');
    const primaryColor300 = documentStyle.getPropertyValue('--p-primary-200');
    const borderColor = documentStyle.getPropertyValue('--surface-border');

    overviewChartData.value = {
        labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
        datasets: [
            {
                label: 'Organic',
                data: [2, 1, 0.5, 0.6, 0.5, 1.3, 1],
                borderColor: [primaryColor],
                pointBorderColor: 'transparent',
                pointBackgroundColor: 'transparent',
                type: 'line',
                fill: false
            },
            {
                label: 'Referral',
                data: [4.88, 3, 6.2, 4.5, 2.1, 5.1, 4.1],
                backgroundColor: [isDarkTheme.value ? '#879AAF' : '#E4E7EB'],
                hoverBackgroundColor: [primaryColor300],
                fill: true,
                borderRadius: 10,
                borderSkipped: 'top bottom',
                barPercentage: 0.3
            }
        ]
    };

    overviewChartOptions.value = {
        plugins: {
            legend: {
                position: 'bottom',
                align: 'end',
                labels: {
                    color: textColorSecondary
                }
            }
        },
        maintainAspectRatio: false,
        responsive: true,
        hover: {
            mode: 'index'
        },
        scales: {
            y: {
                max: 7,
                min: 0,
                ticks: {
                    stepSize: 0,
                    callback: function (value, index) {
                        if (index === 0) {
                            return value;
                        } else {
                            return value + 'k';
                        }
                    },
                    color: textColorSecondary
                },
                grid: {
                    borderDash: [2, 2],
                    color: borderColor,
                    drawBorder: false
                }
            },
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    beginAtZero: true,
                    color: textColorSecondary
                }
            }
        }
    };
}

watch(() => selectedOverviewWeek.value, changeOverviewWeek);

watch(
    [getPrimary, getSurface, isDarkTheme],
    () => {
        initCharts();
    },
    { immediate: true }
);
</script>

<template>
    <div class="col-span-12 xl:col-span-6">
        <div class="card h-full">
            <div class="flex justify-between items-center mb-4">
                <span class="font-semibold text-xl">Acquisition Overview</span>
                <Select :options="overviewWeeks" v-model="selectedOverviewWeek" optionLabel="name" @onChange="changeOverviewWeek"></Select>
            </div>
            <div class="graph">
                <Chart ref="overviewchart" type="bar" :height="370" :data="overviewChartData" :options="overviewChartOptions"></Chart>
            </div>
        </div>
    </div>
</template>
