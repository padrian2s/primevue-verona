<script setup>
import { ProductService } from '@/service/ProductService';
import { onMounted, ref } from 'vue';

const orderWeek = ref([
    { name: 'This Week', code: '0' },
    { name: 'Last Week', code: '1' }
]);

const selectedOrderWeek = ref(orderWeek.value[0]);

const products = ref([]);
const productsThisWeek = ref([]);
const productsLastWeek = ref([]);

function recentSales(code) {
    if (code === '0') products.value = productsThisWeek.value;
    else products.value = productsLastWeek.value;
}

onMounted(() => {
    ProductService.getProducts().then((data) => {
        products.value = data.slice(0, 5);
        productsThisWeek.value = data.slice(0, 5);
        productsLastWeek.value = data.reverse().slice(0, 5);
    });
});
</script>

<template>
    <div class="card h-full">
        <div class="flex flex-wrap items-center justify-between mb-4 gap-4">
            <div class="font-semibold text-xl">Recent Sales</div>
            <Select :options="orderWeek" v-model="selectedOrderWeek" optionLabel="name" @update:modelValue="recentSales($event.code)" class="w-40"></Select>
        </div>

        <DataTable :value="products" :rows="5">
            <Column header="Image">
                <template #body="slotProps">
                    <img :src="'/demo/images/product/' + slotProps.data.image" class="shadow-lg" :alt="slotProps.data.image" width="50" />
                </template>
            </Column>
            <Column field="name" header="Name" :sortable="true">
                <template #body="slotProps">
                    {{ slotProps.data.name }}
                </template>
            </Column>
            <Column field="category" header="Category" :sortable="true">
                <template #body="slotProps">
                    {{ slotProps.data.category }}
                </template>
            </Column>
            <Column field="price" header="Price" :sortable="true">
                <template #body="slotProps">
                    <td>${{ slotProps.data.price }}</td>
                </template>
            </Column>
            <Column>
                <template #body>
                    <Button type="button" icon="pi pi-search" class="p-button-text"></Button>
                </template>
            </Column>
        </DataTable>
    </div>
</template>
