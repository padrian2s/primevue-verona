<script setup>
import { ref } from 'vue';

const listItems = ref([
    { image: '/demo/images/dashboard/sneaker.png', text: 'Red Sneakers', subtext: 'RX Series', ratio: '+40%' },
    { image: '/demo/images/dashboard/headphones.png', text: 'HF Headphones', subtext: 'Wireless', ratio: '+24%' },
    { image: '/demo/images/dashboard/sunglasses.png', text: 'Sunglasses', subtext: 'UV Protection', ratio: '+17%' }
]);

const activeTab = ref(0);

const activeListItemIndex = ref(1);

const activeListItem = ref({
    image: '/demo/images/dashboard/headphones.svg',
    text: 'HF Headphones',
    subtext: 'Wireless',
    ratio: '+24%'
});

function onTabClick(index) {
    activeTab.value = index;

    if (index === 0) {
        listItems.value = [
            { image: '/demo/images/dashboard/sneaker.png', text: 'Red Sneakers', subtext: 'RX Series', ratio: '+40%' },
            { image: '/demo/images/dashboard/headphones.png', text: 'HF Headphones', subtext: 'Wireless', ratio: '+24%' },
            { image: '/demo/images/dashboard/sunglasses.png', text: 'Sunglasses', subtext: 'UV Protection', ratio: '+17%' }
        ];
    } else if (index === 1) {
        listItems.value = [
            { image: '/demo/images/dashboard/camera.png', text: 'Instant Camera', subtext: 'II-Mark', ratio: '+27%' },
            { image: '/demo/images/dashboard/cupcake.png', text: 'Cupcake', subtext: 'Cinnamon', ratio: '+41%' },
            { image: '/demo/images/dashboard/drink.png', text: 'Cold Drink', subtext: 'Lime', ratio: '+56%' }
        ];
    } else if (index === 2) {
        listItems.value = [
            { image: '/demo/images/dashboard/tripod.png', text: 'Tripod', subtext: 'Stabilizer', ratio: '+34%' },
            { image: '/demo/images/dashboard/headphone2.png', text: 'Headphone', subtext: 'Wireless', ratio: '+67%' },
            { image: '/demo/images/dashboard/spoon.png', text: 'Spoon Set', subtext: 'Colorful', ratio: '+8%' }
        ];
    }

    activeListItem.value = listItems.value[activeListItemIndex.value];
}
</script>

<template>
    <div class="card h-full">
        <div class="font-semibold text-xl mb-4">Store Overview</div>
        <div class="flex flex-wrap gap-8">
            <ul class="flex-1 list-none p-0 m-0">
                <li
                    v-for="(item, i) in listItems"
                    :key="i"
                    @click="
                        activeListItemIndex = i;
                        activeListItem = item;
                    "
                    class="rounded-border p-4 flex cursor-pointer border border-transparent"
                    :class="{ '!border-primary-500': activeListItemIndex === i, 'hover:bg-emphasis': activeListItemIndex !== i }"
                >
                    <img :src="item.image" width="64" class="mr-4 rounded-border" />
                    <div class="flex-1 flex items-center justify-between">
                        <div class="flex flex-col">
                            <span class="font-bold">{{ item.text }}</span>
                            <span class="text-muted-color mb-1">{{ item.subtext }}</span>
                            <Badge :value="item.ratio"></Badge>
                        </div>
                        <i class="pi pi-chevron-right text-muted-color ml-4"></i>
                    </div>
                </li>
            </ul>

            <div class="flex-1 flex flex-col items-center justify-center">
                <div class="bars flex items-end mb-6">
                    <div class="w-4 h-8 mr-2 bg-surface-200 dark:bg-surface-600 rounded-border" :class="{ 'h-3rem bg-primary-500': activeListItemIndex === 2 && activeTab === 0 }"></div>
                    <div class="w-4 h-12 mr-2 bg-surface-200 dark:bg-surface-600 rounded-border" :class="{ 'h-5rem bg-primary-500': activeListItemIndex === 1 && activeTab !== 2 }"></div>
                    <div class="w-4 h-16 mr-2 bg-surface-200 dark:bg-surface-600 rounded-border"></div>
                    <div class="w-4 h-24 mr-2 bg-surface-200 dark:bg-surface-600 rounded-border" :class="{ 'h-4rem bg-primary-500': activeListItemIndex === 2 && activeTab !== 0 }"></div>
                    <div class="w-4 h-8 mr-2 bg-surface-200 dark:bg-surface-600 rounded-border" :class="{ 'h-4rem bg-primary-500': activeListItemIndex === 1 && activeTab === 2 }"></div>
                    <div class="w-4 h-20 mr-2 bg-surface-200 dark:bg-surface-600 rounded-border" :class="{ 'h-4rem bg-primary-500': activeListItemIndex === 0 && activeTab === 1 }"></div>
                    <div class="w-4 h-12 mr-2 bg-surface-200 dark:bg-surface-600 rounded-border" :class="{ 'h-4rem bg-primary-500': activeListItemIndex === 0 && activeTab !== 1 }"></div>
                    <div class="w-4 h-4 mr-2 bg-surface-200 dark:bg-surface-600 rounded-border"></div>
                </div>
                <span class="font-bold">{{ activeListItem.text }}</span>
                <span class="text-muted-color">{{ activeListItem.subtext }}</span>
            </div>
        </div>
        <div class="flex items-center mt-16 rounded-border">
            <div class="flex flex-col items-center flex-1 py-4 cursor-pointer border-t hover:bg-emphasis" :class="{ 'border-primary-500': activeTab === 0, 'surface-border': activeTab !== 0 }" @click="onTabClick(0)">
                <i class="pi pi-sort-amount-down text-2xl mb-2"></i>
                <span class="font-bold">Latest</span>
            </div>
            <div class="flex flex-col items-center flex-1 py-4 cursor-pointer border-t hover:bg-emphasis" :class="{ 'border-primary-500': activeTab === 1, 'surface-border': activeTab !== 1 }" @click="onTabClick(1)">
                <i class="pi pi-chart-line text-2xl mb-2"></i>
                <span class="font-bold">Trending</span>
            </div>
            <div class="flex flex-col items-center flex-1 py-4 cursor-pointer border-t hover:bg-emphasis" :class="{ 'border-primary-500': activeTab === 2, 'surface-border': activeTab !== 2 }" @click="onTabClick(2)">
                <i class="pi pi-star text-2xl mb-2"></i>
                <span class="font-bold">Starred</span>
            </div>
        </div>
    </div>
</template>
