<script setup>
import { ref } from 'vue';

const revenueChart = ref({
    labels: ['Online', 'Retail', 'Partner'],
    datasets: [
        {
            data: [12, 32, 56],
            backgroundColor: [
                getComputedStyle(document.documentElement).getPropertyValue('--p-indigo-500'),
                getComputedStyle(document.documentElement).getPropertyValue('--p-teal-500'),
                getComputedStyle(document.documentElement).getPropertyValue('--p-purple-500')
            ],
            borderWidth: 0
        }
    ]
});

const revenueOptions = ref({
    plugins: {
        legend: {
            display: false
        }
    },
    responsive: true,
    cutout: 60
});
</script>

<template>
    <div class="card h-full">
        <div class="flex items-center justify-between mb-4">
            <div class="font-semibold text-xl mb-4 class=">Revenue Stream</div>
            <div class="flex items-center gap-2">
                <Button type="button" icon="pi pi-angle-left" outlined rounded plain></Button>
                <Button type="button" icon="pi pi-angle-right" outlined rounded plain></Button>
            </div>
        </div>
        <div class="flex flex-col items-center justify-center">
            <Chart type="doughnut" :data="revenueChart" :options="revenueOptions" :width="180" :height="180" class="mb-8"></Chart>
            <span class="font-bold mb-2">Total Revenue This Week</span>
            <span class="font-bold text-6xl mb-2">88k</span>
            <span class="font-bold mb-6 text-green-500">+21%<span class="text-muted-color"> higher than last week</span></span>
            <div class="flex items-center justify-center gap-4">
                <div class="flex items-center">
                    <i class="pi pi-circle-on text-indigo-500"></i>
                    <span class="text-muted-color ml-2">Online</span>
                </div>
                <div class="flex items-center">
                    <i class="pi pi-circle-on text-teal-500"></i>
                    <span class="text-muted-color ml-2">Retail</span>
                </div>
                <div class="flex items-center">
                    <i class="pi pi-circle-on text-purple-500"></i>
                    <span class="text-muted-color ml-2">Partner</span>
                </div>
            </div>
        </div>
    </div>
</template>
