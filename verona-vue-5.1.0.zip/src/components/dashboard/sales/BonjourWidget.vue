<script setup>
import { ref } from 'vue';

const analytics = ref([
    { label: 'Products', value: 1 },
    { label: 'Sales', value: 2 },
    { label: 'Customers', value: 3 }
]);

const selectedDrop = ref(0);
const dates = ref();
</script>

<template>
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-4 gap-4">
        <div class="flex items-center">
            <img src="/demo/images/avatar/profile.jpg" :width="64" alt="profile" class="rounded-full border-2 border-primary shrink-0" />
            <div class="ml-4">
                <span class="text-4xl font-light">Bonjour, <span class="font-normal">Hermione</span></span>
                <div class="text-muted-color">26 January 2023, Thu</div>
            </div>
        </div>
        <div class="flex items-center justify-between gap-4">
            <Select :options="analytics" v-model="selectedDrop" placeholder="Category" class="w-full sm:w-40" optionLabel="label"></Select>
            <DatePicker v-model="dates" showIcon selectionMode="range" class="w-full sm:w-56" placeholder="Select Range"></DatePicker>
        </div>
    </div>
</template>
