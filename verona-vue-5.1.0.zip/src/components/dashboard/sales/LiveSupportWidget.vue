<script setup>
import { nextTick, ref } from 'vue';

const chatMessages = ref([
    { self: false, from: 'Jane Cooper', url: '/demo/images/avatar/stephenshaw.png', messages: ['Hey M. hope you are well. Our idea is accepted by the board. '] },
    { self: true, from: 'Jerome Bell', url: '/demo/images/avatar/ivanmagalhaes.png', messages: ['we did it! 🤠'] },
    { self: false, from: 'Darlene Robertson', url: '/demo/images/avatar/amyelsner.png', messages: ['I will be looking at the process then, just to be sure 🤓 '] }
]);

async function onChatKeydown(event) {
    if (event.key === 'Enter') {
        const message = event.target.value;
        const lastMessage = chatMessages.value[chatMessages.value.length - 1];

        if (lastMessage.from) {
            chatMessages.value.push({
                self: true,
                from: 'Jerome Bell',
                url: '/demo/images/avatar/ivanmagalhaes.png',
                messages: [message]
            });
        } else {
            lastMessage.messages.push(message);
        }

        if (message.match(/primeng|primereact|primefaces|primevue/i)) {
            chatMessages.value.push({
                nth: false,
                from: 'Ioni Bowcher',
                url: '/demo/images/avatar/ionibowcher.png',
                messages: ['Always bet on Prime!']
            });
        }

        event.target.value = '';

        await nextTick();
        const chatContainer = document.querySelector('.chat-container');
        chatContainer.scrollTo({
            top: chatContainer.scrollHeight,
            behavior: 'smooth'
        });
    }
}
</script>

<template>
    <div class="card h-full">
        <div class="font-semibold text-xl mb-4">Live Support</div>
        <div>
            <ul ref="chatcontainer" class="chat-container list-none p-0 px-4 mt-6 mb-12 h-[21rem] overflow-y-auto">
                <li v-for="(chartMessage, index) in chatMessages" :key="index" class="flex items-start mb-4" :class="{ 'justify-content-start': !chartMessage.self, 'justify-end': chartMessage.self }">
                    <img v-if="!chartMessage.self" :src="chartMessage.url" width="36" height="36" class="rounded-full" />
                    <div v-if="!chartMessage.self" class="ml-2 flex flex-col items-start">
                        <div>
                            <span class="font-bold mr-4">{{ chartMessage.from }}</span>
                            <span class="text-muted-color">2m ago</span>
                        </div>
                        <div v-for="(message, messageIndex) in chartMessage.messages" :key="messageIndex" class="inline-block text-left bg-surface-100 dark:bg-surface-700 rounded-border px-8 py-4 mt-4">
                            {{ message }}
                        </div>
                    </div>
                    <div v-if="chartMessage.self" class="mr-4 flex flex-col items-end">
                        <div>
                            <span class="text-muted-color">2m ago</span>
                            <span class="font-bold ml-4">{{ chartMessage.from }}</span>
                        </div>
                        <div v-for="(message, messageIndex) in chartMessage.messages" :key="messageIndex" class="inline-block text-right bg-primary-500 text-primary-50 rounded-border px-8 py-4 mt-4">
                            {{ message }}
                        </div>
                    </div>
                    <img v-if="chartMessage.self" :src="chartMessage.url" width="36" height="36" class="rounded-full" />
                </li>
            </ul>
            <InputGroup class="mt-4">
                <InputText type="text" placeholder="Write your message (Hint: 'PrimeVue')" @keydown="onChatKeydown($event)" />
            </InputGroup>
        </div>
    </div>
</template>
