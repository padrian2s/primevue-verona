<script setup>
import { ref } from 'vue';

const value1 = ref(75);
const value2 = ref(20);
const value3 = ref(42);
const value4 = ref(26);
const value5 = ref(10);
const value6 = ref(60);
</script>

<template>
    <div class="card h-full">
        <div class="font-semibold text-xl mb-4">Best Sellers</div>
        <ul class="list-none p-0 m-0">
            <li class="flex items-center justify-between pb-2">
                <div class="flex items-center justify-between">
                    <img src="/demo/images/product/bamboo-watch.png" alt="verona-layout" class="w-12 h-12 rounded-border" />
                    <div class="ml-2 flex flex-col">
                        <span class="font-bold">Bamboo Watch</span>
                        <span class="text-muted-color text-sm">Accessories</span>
                    </div>
                </div>
                <Knob v-model="value1" :size="40" class="ml-auto" :showValue="false"></Knob>
            </li>
            <li class="flex items-center justify-between py-2">
                <div class="flex items-center justify-between">
                    <img src="/demo/images/product/black-watch.png" alt="verona-layout" width="42" height="42" class="rounded-border" />
                    <div class="ml-2 flex flex-col">
                        <span class="font-bold">Black Watch</span>
                        <span class="text-muted-color text-sm">Accessories</span>
                    </div>
                </div>
                <Knob v-model="value2" :size="40" class="ml-auto" :showValue="false"></Knob>
            </li>
            <li class="flex items-center justify-between py-2">
                <div class="flex items-center justify-between">
                    <img src="/demo/images/product/blue-band.png" alt="verona-layout" width="42" height="42" class="rounded-border" />
                    <div class="ml-2 flex flex-col">
                        <span class="font-bold">Blue Band</span>
                        <span class="text-muted-color text-sm">Fitness</span>
                    </div>
                </div>
                <Knob v-model="value3" :size="40" class="ml-auto" :showValue="false"></Knob>
            </li>
            <li class="flex items-center justify-between py-2">
                <div class="flex items-center justify-between">
                    <img src="/demo/images/product/blue-t-shirt.png" alt="verona-layout" width="42" height="42" class="rounded-border" />
                    <div class="ml-2 flex flex-col">
                        <span class="font-bold">Blue T-Shirt</span>
                        <span class="text-muted-color text-sm">Clothing</span>
                    </div>
                </div>
                <Knob v-model="value4" :size="40" class="ml-auto" :showValue="false"></Knob>
            </li>
            <li class="flex items-center justify-between py-2">
                <div class="flex items-center justify-between">
                    <img src="/demo/images/product/black-watch.png" alt="verona-layout" width="42" height="42" class="rounded-border" />
                    <div class="ml-2 flex flex-col">
                        <span class="font-bold">Black Watch</span>
                        <span class="text-muted-color text-sm">Accessories</span>
                    </div>
                </div>
                <Knob v-model="value5" :size="40" class="ml-auto" :showValue="false"></Knob>
            </li>
            <li class="flex items-center justify-between py-2">
                <div class="flex items-center justify-between">
                    <img src="/demo/images/product/sneakers.jpg" alt="verona-layout" width="42" height="42" class="rounded-border" />
                    <div class="ml-2 flex flex-col">
                        <span class="font-bold">Sneakers</span>
                        <span class="text-muted-color text-sm">Clothing</span>
                    </div>
                </div>
                <Knob v-model="value6" :size="40" class="ml-auto" :showValue="false"></Knob>
            </li>
        </ul>
    </div>
</template>
