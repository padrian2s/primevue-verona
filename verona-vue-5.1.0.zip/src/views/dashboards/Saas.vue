<script setup>
import AcquisitionOverviewWidget from '@/components/dashboard/saas/AcquisitionOverviewWidget.vue';
import LatestCustomerWidget from '@/components/dashboard/saas/LatestCustomerWidget.vue';
import LeadsByRoleWidget from '@/components/dashboard/saas/LeadsByRoleWidget.vue';
import MonthlyRecurringWidget from '@/components/dashboard/saas/MonthlyRecurringWidget.vue';
import ProfileWidget from '@/components/dashboard/saas/ProfileWidget.vue';
import RecentBlogPostWidget from '@/components/dashboard/saas/RecentBlogPostWidget.vue';
import StatsSaasWidget from '@/components/dashboard/saas/StatsSaasWidget.vue';
import TimelineWidget from '@/components/dashboard/saas/TimelineWidget.vue';
import TrialsLeadsWidget from '@/components/dashboard/saas/TrialsLeadsWidget.vue';
</script>

<template>
    <div class="grid grid-cols-12 gap-8 mb-4">
        <StatsSaasWidget />
        <AcquisitionOverviewWidget />

        <div class="col-span-12 lg:col-span-6 xl:col-span-3">
            <LatestCustomerWidget />
        </div>

        <div class="col-span-12 lg:col-span-6 xl:col-span-3">
            <ProfileWidget />
        </div>

        <div class="col-span-12 lg:col-span-6 xl:col-span-4">
            <TrialsLeadsWidget />
        </div>

        <div class="col-span-12 lg:col-span-6 xl:col-span-4">
            <LeadsByRoleWidget />
        </div>

        <div class="col-span-12 lg:col-span-6 xl:col-span-4">
            <RecentBlogPostWidget />
        </div>

        <div class="col-span-12 lg:col-span-6">
            <TimelineWidget />
        </div>
        <div class="col-span-12 xl:col-span-6">
            <MonthlyRecurringWidget />
        </div>
    </div>
</template>
