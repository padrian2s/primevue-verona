<script setup>
import BestSellersWidget from '@/components/dashboard/sales/BestSellersWidget.vue';
import BonjourWidget from '@/components/dashboard/sales/BonjourWidget.vue';
import CustomerStoriesWidget from '@/components/dashboard/sales/CustomerStoriesWidget.vue';
import LiveSupportWidget from '@/components/dashboard/sales/LiveSupportWidget.vue';
import OptimizingWidget from '@/components/dashboard/sales/OptimizingWidget.vue';
import PotentialInfluencersWidget from '@/components/dashboard/sales/PotentialInfluencersWidget.vue';
import RecentSalesWidget from '@/components/dashboard/sales/RecentSalesWidget.vue';
import RevenueStreamWidget from '@/components/dashboard/sales/RevenueStreamWidget.vue';
import SalesChannelsWidget from '@/components/dashboard/sales/SalesChannelsWidget.vue';
import StatsSalesWidget from '@/components/dashboard/sales/StatsSalesWidget.vue';
import StoreOverviewWidget from '@/components/dashboard/sales/StoreOverviewWidget.vue';
</script>

<template>
    <div class="grid grid-cols-12 gap-8 mb-4">
        <div class="col-span-12">
            <BonjourWidget />
        </div>

        <div class="col-span-12">
            <StatsSalesWidget />
        </div>

        <div class="col-span-12 lg:col-span-6">
            <StoreOverviewWidget />
        </div>

        <div class="col-span-12 lg:col-span-6">
            <RecentSalesWidget />
        </div>

        <div class="col-span-12 md:col-span-6 xl:col-span-6">
            <LiveSupportWidget />
        </div>

        <div class="col-span-12 md:col-span-6 xl:col-span-3">
            <RevenueStreamWidget />
        </div>

        <div class="col-span-12 md:col-span-6 lg:col-span-3">
            <SalesChannelsWidget />
        </div>

        <div class="col-span-12 md:col-span-6 xl:col-span-3">
            <OptimizingWidget />
        </div>

        <div class="col-span-12 md:col-span-6 xl:col-span-3">
            <BestSellersWidget />
        </div>

        <div class="col-span-12 md:col-span-6 lg:col-span-6">
            <CustomerStoriesWidget />
            <PotentialInfluencersWidget />
        </div>
    </div>
</template>
