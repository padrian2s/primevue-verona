<template>
    <div class="grid grid-cols-12 gap-4">
        <div class="col-span-12">
            <div class="card">
                <div class="font-semibold text-xl mb-4">Empty Page</div>
                <p>Use this page to start from scratch and place your custom content.</p>
            </div>
        </div>
    </div>
</template>
