<script setup>
import AppConfig from '@/layout/AppConfig.vue';
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const val1 = ref(null);
const val2 = ref(null);
const val3 = ref(null);
const val4 = ref(null);

function navigateToDashboard() {
    router.push('/');
}

function onDigitInput(event) {
    let element;
    if (event.code !== 'Backspace') {
        if (event.code.includes('Numpad') || event.code.includes('Digit')) {
            element = event.target.nextElementSibling;
        }
    }
    if (event.code === 'Backspace') {
        element = event.target.previousElementSibling;
    }

    if (element == null) return;
    else element.focus();
}
</script>

<template>
    <div class="bg-surface-100 dark:bg-surface-950 h-screen w-screen flex items-center justify-center">
        <div class="bg-surface-0 dark:bg-surface-900 py-16 px-8 sm:px-16 shadow flex flex-col w-11/12 sm:w-[30rem]" style="border-radius: 14px">
            <h1 class="font-bold text-2xl mt-0 mb-2">Verification Code</h1>
            <p class="text-muted-color mb-6">Enter code we sent in your mail!</p>

            <div class="flex items-center mb-6 gap-2">
                <InputText v-model="val1" class="w-20 text-center" maxlength="1" @keyup="onDigitInput($event)" />
                <InputText v-model="val2" class="w-20 text-center" maxlength="1" @keyup="onDigitInput($event)" />
                <InputText v-model="val3" class="w-20 text-center" maxlength="1" @keyup="onDigitInput($event)" />
                <InputText v-model="val4" class="w-20 text-center" maxlength="1" @keyup="onDigitInput($event)" />
            </div>

            <Button label="Verify" class="mb-6" @click="navigateToDashboard"></Button>
            <span class="text-muted-color text-center">If you didn't get the mail? <span class="font-bold text-primary-500">Send code again</span></span>
        </div>
    </div>

    <AppConfig simple />
</template>
