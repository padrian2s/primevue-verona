<script setup>
import AppConfig from '@/layout/AppConfig.vue';
import { useRouter } from 'vue-router';

const router = useRouter();

function navigateToDashboard() {
    router.push('/');
}
</script>

<template>
    <div class="bg-surface-100 dark:bg-surface-950 h-screen w-screen flex items-center justify-center">
        <div class="bg-surface-0 dark:bg-surface-900 py-16 px-8 sm:px-16 shadow flex flex-col w-11/12 sm:w-[30rem]" style="border-radius: 14px">
            <h1 class="font-bold text-2xl mt-0 mb-2">Forgot Password?</h1>
            <p class="text-muted-color mb-6">We need your email address for you can access your account, then we’ll send a recovery mail.</p>

            <IconField class="mb-6">
                <InputIcon class="pi pi-user" />
                <InputText type="text" placeholder="Email" class="w-full" />
            </IconField>

            <Button label="Send Recovery Mail" @click="navigateToDashboard"></Button>
        </div>
    </div>

    <AppConfig simple />
</template>
