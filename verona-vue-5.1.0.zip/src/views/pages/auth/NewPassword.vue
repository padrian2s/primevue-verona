<script setup>
import AppConfig from '@/layout/AppConfig.vue';
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const value1 = ref(null);
const value2 = ref(null);

function navigateToDashboard() {
    router.push('/');
}
</script>

<template>
    <div class="bg-surface-100 dark:bg-surface-950 h-screen w-screen flex items-center justify-center">
        <div class="bg-surface-0 dark:bg-surface-900 py-16 px-8 sm:px-16 shadow flex flex-col w-11/12 sm:w-[30rem]" style="border-radius: 14px">
            <h1 class="font-bold text-2xl mt-0 mb-2">New Password</h1>
            <p class="text-muted-color mb-6">Enter your new password.</p>

            <IconField class="mb-6">
                <InputIcon class="pi pi-key z-20" />
                <Password id="password" placeholder="Password" v-model="value1" class="w-full" :inputStyle="{ paddingLeft: '2.5rem' }" inputClass="w-full" :toggleMask="true"></Password>
            </IconField>

            <IconField class="mb-6">
                <InputIcon class="pi pi-key z-20" />
                <Password id="password" placeholder="Confirm Password" v-model="value2" class="w-full" :inputStyle="{ paddingLeft: '2.5rem' }" inputClass="w-full" :toggleMask="true" :feedback="false"></Password>
            </IconField>

            <Button label="Submit" @click="navigateToDashboard"></Button>
        </div>
    </div>

    <AppConfig simple />
</template>
