<script setup>
import AppConfig from '@/layout/AppConfig.vue';
import { useRouter } from 'vue-router';

const router = useRouter();

function navigateToDashboard() {
    router.push('/');
}
</script>

<template>
    <div class="bg-surface-100 dark:bg-surface-950 h-screen w-screen flex items-center justify-center">
        <div class="bg-surface-0 dark:bg-surface-900 py-16 px-8 sm:px-16 shadow flex flex-col w-11/12 sm:w-[30rem]" style="border-radius: 14px">
            <h1 class="font-bold text-2xl mt-0 mb-2">ERROR</h1>
            <p class="text-muted-color mb-6">Unexpected error happened. Resource is not available.</p>
            <img src="/demo/images/pages/auth/error.svg" alt="error" class="mb-6 self-center" />
            <Button label="Go to Dashboard" @click="navigateToDashboard"></Button>
        </div>
    </div>

    <AppConfig simple />
</template>
