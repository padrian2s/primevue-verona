<script setup>
import AppConfig from '@/layout/AppConfig.vue';
import { useRouter } from 'vue-router';

const router = useRouter();

function navigateToDashboard() {
    router.push('/');
}
</script>

<template>
    <div class="bg-surface-100 dark:bg-surface-950 h-screen w-screen flex items-center justify-center">
        <div class="bg-surface-0 dark:bg-surface-900 py-16 px-8 sm:px-16 shadow flex flex-col w-11/12 sm:w-[30rem]" style="border-radius: 14px">
            <h1 class="font-bold text-2xl mt-0 mb-2">VERONA</h1>
            <p class="text-muted-color mb-6">Welcome to the <strong>Verona Community</strong>, where the magic happens, sign in to continue.</p>

            <IconField class="mb-6">
                <InputIcon class="pi pi-user" />
                <InputText type="text" placeholder="Email" class="w-full" />
            </IconField>

            <IconField class="mb-6">
                <InputIcon class="pi pi-key" />
                <InputText type="password" placeholder="Password" class="w-full" />
            </IconField>

            <Button label="Sign In" class="mb-6" @click="navigateToDashboard"></Button>

            <span class="text-muted-color text-center mb-6">or sign in with below</span>

            <div class="flex gap-6 items-center justify-center">
                <a href="https://www.facebook.com" class="inline-flex shrink-0 w-12 h-12 justify-center items-center bg-surface-50 dark:bg-surface-950 rounded-full">
                    <i class="pi pi-facebook !text-2xl text-color"></i>
                </a>
                <a href="https://www.twitter.com" class="inline-flex shrink-0 w-12 h-12 justify-center items-center bg-surface-50 dark:bg-surface-950 rounded-full">
                    <i class="pi pi-twitter !text-2xl text-color"></i>
                </a>
                <a href="https://www.google.com" class="inline-flex shrink-0 w-12 h-12 justify-center items-center bg-surface-50 dark:bg-surface-950 rounded-full">
                    <i class="pi pi-google !text-2xl text-color"></i>
                </a>
                <a href="https://www.github.com" class="inline-flex shrink-0 w-12 h-12 justify-center items-center bg-surface-50 dark:bg-surface-950 rounded-full">
                    <i class="pi pi-github !text-2xl text-color"></i>
                </a>
            </div>
        </div>
    </div>

    <AppConfig simple />
</template>
