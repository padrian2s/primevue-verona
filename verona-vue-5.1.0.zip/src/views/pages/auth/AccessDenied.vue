<script setup>
import AppConfig from '@/layout/AppConfig.vue';
import { useRouter } from 'vue-router';

const router = useRouter();

function navigateToDashboard() {
    router.push('/');
}
</script>

<template>
    <div class="bg-surface-50 dark:bg-surface-950 h-screen w-screen flex items-center justify-center">
        <div class="bg-surface-0 dark:bg-surface-900 py-16 px-8 sm:px-16 shadow flex flex-col w-11/12 sm:w-[30rem]" style="border-radius: 14px">
            <h1 class="font-bold text-2xl mt-0 mb-2">ACCESS DENIED</h1>
            <p class="text-muted-color mb-6">You are not authorized to access this resource..</p>
            <img src="/demo/images/pages/auth/access-denied.svg" alt="access-denied" class="mb-6 self-center" />
            <Button label="Go to Dashboard" @click="navigateToDashboard"></Button>
        </div>
    </div>

    <AppConfig simple />
</template>
