<script setup>
import FeaturesWidget from '@/components/landing/FeaturesWidget.vue';
import FooterWidget from '@/components/landing/FooterWidget.vue';
import HeaderWidget from '@/components/landing/HeaderWidget.vue';
import HeroWidget from '@/components/landing/HeroWidget.vue';
import JoinWidget from '@/components/landing/JoinWidget.vue';
import PricingWidget from '@/components/landing/PricingWidget.vue';
import StatsWidget from '@/components/landing/StatsWidget.vue';
import AppConfig from '@/layout/AppConfig.vue';
import { useLayout } from '@/layout/composables/layout';
import { computed } from 'vue';

const { isDarkTheme } = useLayout();

const backgroundStyle = computed(() => {
    let path = '/demo/images/landing/';
    let image = isDarkTheme.value ? 'line-effect-dark.svg' : 'line-effect.svg';

    return { 'background-image': `url(${path + image})` };
});
</script>

<template>
    <div class="bg-surface-50 dark:bg-surface-950 min-h-screen w-screen">
        <div class="landing-wrapper">
            <div :style="backgroundStyle" class="bg-no-repeat bg-cover bg-bottom">
                <HeaderWidget />
                <HeroWidget />
                <StatsWidget />
            </div>
            <FeaturesWidget />
            <JoinWidget />
            <PricingWidget />
            <FooterWidget />
        </div>
    </div>
    <AppConfig simple />
</template>
