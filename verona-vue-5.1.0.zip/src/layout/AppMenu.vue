<script setup>
import { ref } from 'vue';
import AppMenuItem from './AppMenuItem.vue';

const model = ref([
    {
        label: 'Dashboard',
        icon: 'pi pi-home',
        items: [
            {
                label: 'SaaS',
                icon: 'pi pi-desktop',
                to: '/'
            },
            {
                label: 'Sales',
                icon: 'pi pi-chart-bar',
                to: '/dashboard-sales'
            }
        ]
    },
    {
        label: 'UI Kit',
        icon: 'pi pi-star',
        items: [
            {
                label: 'Form Layout',
                icon: 'pi pi-id-card',
                to: '/uikit/formlayout'
            },
            {
                label: 'Input',
                icon: 'pi pi-check-square',
                to: '/uikit/input'
            },
            {
                label: 'Button',
                icon: 'pi pi-box',
                to: '/uikit/button'
            },
            {
                label: 'Table',
                icon: 'pi pi-table',
                to: '/uikit/table'
            },
            {
                label: 'List',
                icon: 'pi pi-list',
                to: '/uikit/list'
            },
            {
                label: 'Tree',
                icon: 'pi pi-share-alt',
                to: '/uikit/tree'
            },
            {
                label: 'Panel',
                icon: 'pi pi-tablet',
                to: '/uikit/panel'
            },
            {
                label: 'Overlay',
                icon: 'pi pi-clone',
                to: '/uikit/overlay'
            },
            {
                label: 'Media',
                icon: 'pi pi-image',
                to: '/uikit/media'
            },
            {
                label: 'Menu',
                icon: 'pi pi-bars',
                to: '/uikit/menu'
            },
            {
                label: 'Message',
                icon: 'pi pi-comment',
                to: '/uikit/message'
            },
            {
                label: 'File',
                icon: 'pi pi-file',
                to: '/uikit/file'
            },
            {
                label: 'Chart',
                icon: 'pi pi-chart-bar',
                to: '/uikit/charts'
            },
            {
                label: 'Timeline',
                icon: 'pi pi-calendar',
                to: '/uikit/timeline'
            },
            {
                label: 'Misc',
                icon: 'pi pi-circle-off',
                to: '/uikit/misc'
            }
        ]
    },
    {
        label: 'Apps',
        icon: 'pi pi-th-large',
        items: [
            {
                label: 'Blog',
                icon: 'pi pi-comment',
                items: [
                    {
                        label: 'List',
                        icon: 'pi pi-image',
                        to: '/apps/blog/list'
                    },
                    {
                        label: 'Detail',
                        icon: 'pi pi-list',
                        to: '/apps/blog/detail'
                    },
                    {
                        label: 'Edit',
                        icon: 'pi pi-pencil',
                        to: '/apps/blog/edit'
                    }
                ]
            },
            {
                label: 'Chat',
                icon: 'pi pi-comments',
                to: '/apps/chat'
            },
            {
                label: 'Files',
                icon: 'pi pi-folder',
                to: '/apps/files'
            },
            {
                label: 'Mail',
                icon: 'pi pi-envelope',
                items: [
                    {
                        label: 'Inbox',
                        icon: 'pi pi-inbox',
                        to: '/apps/mail/inbox'
                    },
                    {
                        label: 'Compose',
                        icon: 'pi pi-pencil',
                        to: '/apps/mail/compose'
                    },
                    {
                        label: 'Detail',
                        icon: 'pi pi-comment',
                        to: '/apps/mail/detail/1000'
                    }
                ]
            },
            {
                label: 'Task List',
                icon: 'pi pi-check-square',
                to: '/apps/tasklist'
            }
        ]
    },

    {
        label: 'Prime Blocks',
        icon: 'pi pi-prime',
        items: [
            {
                label: 'Free Blocks',
                icon: 'pi pi-eye',
                to: '/blocks'
            },
            {
                label: 'All Blocks',
                icon: 'pi pi-globe',
                url: 'https://blocks.primevue.org',
                target: '_blank'
            }
        ]
    },
    {
        label: 'Utilities',
        icon: 'pi pi-compass',
        items: [
            {
                label: 'Figma',
                icon: 'pi pi-pencil',
                url: 'https://www.figma.com/file/PgQXX4HXMPeCkT74tGajod/Preview-%7C-Verona-2022?type=design&node-id=1303-750&mode=design',
                target: '_blank'
            }
        ]
    },
    {
        label: 'Pages',
        icon: 'pi pi-briefcase',
        items: [
            {
                label: 'Landing',
                icon: 'pi pi-globe',
                to: '/landing'
            },
            {
                label: 'Auth',
                icon: 'pi pi-user',
                items: [
                    {
                        label: 'Login',
                        icon: 'pi pi-sign-in',
                        to: '/auth/login'
                    },
                    {
                        label: 'Error',
                        icon: 'pi pi-times-circle',
                        to: '/auth/error'
                    },
                    {
                        label: 'Access Denied',
                        icon: 'pi pi-lock',
                        to: '/auth/access'
                    },
                    {
                        label: 'Register',
                        icon: 'pi pi-user-plus',
                        to: '/auth/register'
                    },
                    {
                        label: 'Forgot Password',
                        icon: 'pi pi-question',
                        to: '/auth/forgotpassword'
                    },
                    {
                        label: 'New Password',
                        icon: 'pi pi-cog',
                        to: '/auth/newpassword'
                    },
                    {
                        label: 'Verification',
                        icon: 'pi pi-envelope',
                        to: '/auth/verification'
                    },
                    {
                        label: 'Lock Screen',
                        icon: 'pi pi-eye-slash',
                        to: '/auth/lockscreen'
                    }
                ]
            },
            {
                label: 'Crud',
                icon: 'pi pi-pencil',
                to: '/pages/crud'
            },
            {
                label: 'Invoice',
                icon: 'pi pi-dollar',
                to: '/pages/invoice'
            },
            {
                label: 'Help',
                icon: 'pi pi-question-circle',
                to: '/pages/help'
            },
            {
                label: 'Not Found',
                icon: 'pi pi-exclamation-circle',
                to: '/pages/notfound'
            },
            {
                label: 'Empty',
                icon: 'pi pi-circle-off',
                to: '/pages/empty'
            },
            {
                label: 'Contact Us',
                icon: 'pi pi-phone',
                to: '/pages/contact'
            }
        ]
    },
    {
        label: 'E-Commerce',
        icon: 'pi pi-wallet',
        items: [
            {
                label: 'Product Overview',
                icon: 'pi pi-image',
                to: '/ecommerce/product-overview'
            },
            {
                label: 'Product List',
                icon: 'pi pi-list',
                to: '/ecommerce/product-list'
            },
            {
                label: 'New Product',
                icon: 'pi pi-plus',
                to: '/ecommerce/new-product'
            },
            {
                label: 'Shopping Cart',
                icon: 'pi pi-shopping-cart',
                to: '/ecommerce/shopping-cart'
            },
            {
                label: 'Checkout Form',
                icon: 'pi pi-check-square',
                to: '/ecommerce/checkout-form'
            },
            {
                label: 'Order History',
                icon: 'pi pi-history',
                to: '/ecommerce/order-history'
            },
            {
                label: 'Order Summary',
                icon: 'pi pi-file',
                to: '/ecommerce/order-summary'
            }
        ]
    },

    {
        label: 'User Management',
        icon: 'pi pi-user',
        items: [
            {
                label: 'List',
                icon: 'pi pi-list',
                to: '/profile/list'
            },
            {
                label: 'Create',
                icon: 'pi pi-plus',
                to: '/profile/create'
            }
        ]
    },
    {
        label: 'Hierarchy',
        icon: 'pi pi-align-left',
        items: [
            {
                label: 'Submenu 1',
                icon: 'pi pi-align-left',
                items: [
                    {
                        label: 'Submenu 1.1',
                        icon: 'pi pi-align-left',
                        items: [
                            {
                                label: 'Submenu 1.1.1',
                                icon: 'pi pi-align-left'
                            },
                            {
                                label: 'Submenu 1.1.2',
                                icon: 'pi pi-align-left'
                            },
                            {
                                label: 'Submenu 1.1.3',
                                icon: 'pi pi-align-left'
                            }
                        ]
                    },
                    {
                        label: 'Submenu 1.2',
                        icon: 'pi pi-align-left',
                        items: [
                            {
                                label: 'Submenu 1.2.1',
                                icon: 'pi pi-align-left'
                            }
                        ]
                    }
                ]
            },
            {
                label: 'Submenu 2',
                icon: 'pi pi-align-left',
                items: [
                    {
                        label: 'Submenu 2.1',
                        icon: 'pi pi-align-left',
                        items: [
                            {
                                label: 'Submenu 2.1.1',
                                icon: 'pi pi-align-left'
                            },
                            {
                                label: 'Submenu 2.1.2',
                                icon: 'pi pi-align-left'
                            }
                        ]
                    },
                    {
                        label: 'Submenu 2.2',
                        icon: 'pi pi-align-left',
                        items: [
                            {
                                label: 'Submenu 2.2.1',
                                icon: 'pi pi-align-left'
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        label: 'Start',
        icon: 'pi pi-download',
        items: [
            {
                label: 'Buy Now',
                icon: 'pi pi-shopping-cart',
                url: 'https://www.primefaces.org/store'
            },
            {
                label: 'Documentation',
                icon: 'pi pi-info-circle',
                to: '/documentation'
            }
        ]
    }
]);
</script>

<template>
    <ul class="layout-menu">
        <template v-for="(item, i) in model" :key="item">
            <AppMenuItem :item="item" root :index="i" />

            <li class="menu-separator"></li>
        </template>
    </ul>
</template>

<style lang="scss" scoped></style>
